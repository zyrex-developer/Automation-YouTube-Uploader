import mimetypes
import os
import time
from googleapiclient.http import MediaFileUpload
from googleapiclient.errors import HttpError

_MAX_RETRIES = 5
_TITLE_MAX = 100
_DESC_MAX = 5000
_TAGS_TOTAL_MAX = 500


def upload_video(
    youtube,
    video_path: str,
    metadata: dict,
    thumbnail_path: str = None,
    publish_at: str = None,
) -> str:
    """Upload a video to YouTube and optionally set a thumbnail and schedule.

    Args:
        youtube: Authenticated YouTube service client.
        video_path: Path to the video file (MP4, MOV, AVI, etc.).
        metadata: Dict with title, description, tags, category_id, default_language.
        thumbnail_path: Optional path to a thumbnail image (JPG/PNG, 1280×720).
        publish_at: Optional ISO 8601 UTC string to schedule publication
                    e.g. "2024-12-25T15:00:00Z". Video is set to private until then.

    Returns:
        YouTube video ID.
    """
    privacy = "private" if publish_at else "public"
    metadata = _validate_metadata(metadata)

    body = {
        "snippet": {
            "title": metadata["title"],
            "description": metadata["description"],
            "tags": metadata.get("tags", []),
            "categoryId": metadata.get("category_id", "22"),
            "defaultLanguage": metadata.get("default_language", "en"),
        },
        "status": {
            "privacyStatus": privacy,
            "selfDeclaredMadeForKids": False,
        },
    }

    if publish_at:
        body["status"]["publishAt"] = publish_at

    mime, _ = mimetypes.guess_type(video_path)
    if not mime or not mime.startswith("video/"):
        mime = "video/*"
    media = MediaFileUpload(video_path, mimetype=mime, chunksize=10 * 1024 * 1024, resumable=True)

    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=media,
    )

    video_id = _execute_resumable_upload(request)

    if thumbnail_path and os.path.exists(thumbnail_path):
        _set_thumbnail(youtube, video_id, thumbnail_path)

    return video_id


def _validate_metadata(metadata: dict) -> dict:
    """Enforce YouTube API field length limits."""
    meta = dict(metadata)
    meta["title"] = meta["title"][:_TITLE_MAX]
    meta["description"] = meta["description"][:_DESC_MAX]

    # Trim tags until total chars fit within limit
    tags = meta.get("tags", [])
    kept, total = [], 0
    for tag in tags:
        tag = tag[:30]  # each tag max 30 chars
        if total + len(tag) > _TAGS_TOTAL_MAX:
            break
        kept.append(tag)
        total += len(tag)
    meta["tags"] = kept
    return meta


def _execute_resumable_upload(request) -> str:
    response = None
    attempt = 0
    while response is None:
        try:
            status, response = request.next_chunk()
            if status:
                pct = int(status.progress() * 100)
                print(f"\r  Uploading... {pct}%", end="", flush=True)
            attempt = 0  # reset on success
        except HttpError as e:
            if e.resp.status in (500, 502, 503, 504) and attempt < _MAX_RETRIES:
                attempt += 1
                delay = 2 ** attempt
                print(f"\n  Transient error ({e.resp.status}), retry {attempt}/{_MAX_RETRIES} in {delay}s...")
                time.sleep(delay)
            else:
                raise
    print()
    return response["id"]


def _set_thumbnail(youtube, video_id: str, thumbnail_path: str):
    print("  Setting thumbnail...")
    mime, _ = mimetypes.guess_type(thumbnail_path)
    if not mime:
        mime = "image/jpeg"
    try:
        youtube.thumbnails().set(
            videoId=video_id,
            media_body=MediaFileUpload(thumbnail_path, mimetype=mime),
        ).execute()
    except HttpError as e:
        print(f"  Warning: could not set thumbnail - {e}")

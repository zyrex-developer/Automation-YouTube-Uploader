"""YouTube Video Posting Automation

Usage examples:
  # Upload with auto-generated metadata from a script
  python main.py video.mp4 --script script.txt --niche "tech tutorials"

  # Upload with thumbnail and scheduled publish time
  python main.py video.mp4 --script script.txt --thumbnail thumb.jpg --schedule 2024-12-25T15:00:00Z

  # Upload immediately as public (no script — uses filename as fallback prompt)
  python main.py video.mp4
"""

import argparse
import os
import sys

from dotenv import load_dotenv

load_dotenv()


def main():
    parser = argparse.ArgumentParser(
        description="Upload a YouTube video with Claude-generated metadata."
    )
    parser.add_argument("video", help="Path to the video file")
    parser.add_argument("--script", help="Path to a script or transcript text file")
    parser.add_argument("--thumbnail", help="Path to a thumbnail image (1280x720 JPG/PNG)")
    parser.add_argument("--niche", default="", help="Channel niche for better SEO targeting")
    parser.add_argument(
        "--schedule",
        help="Schedule publish time in ISO 8601 UTC (e.g. 2024-12-25T15:00:00Z). "
             "Video stays private until then.",
    )
    parser.add_argument(
        "--secrets",
        default="client_secrets.json",
        help="Path to Google OAuth client secrets JSON (default: client_secrets.json)",
    )
    args = parser.parse_args()

    # Validate video file
    if not os.path.exists(args.video):
        print(f"Error: video file not found: {args.video}")
        sys.exit(1)

    # Load script
    script = ""
    if args.script:
        if not os.path.exists(args.script):
            print(f"Error: script file not found: {args.script}")
            sys.exit(1)
        with open(args.script, encoding="utf-8") as f:
            script = f.read()
    else:
        # Fallback: use the video filename as a minimal prompt
        script = f"Video titled: {os.path.basename(args.video)}"
        print("No script provided — using filename as metadata prompt (results may be generic).")

    niche = args.niche or os.getenv("CHANNEL_NICHE", "")

    # 1. Generate metadata with Claude
    print("\n[1/3] Generating metadata with Claude Opus 4.7...")
    from metadata import generate_metadata
    metadata = generate_metadata(script, niche)

    print(f"      Title      : {metadata['title']}")
    print(f"      Category   : {metadata['category_id']}")
    print(f"      Tags       : {', '.join(metadata['tags'][:5])}{'...' if len(metadata['tags']) > 5 else ''}")

    # 2. Authenticate YouTube
    print("\n[2/3] Authenticating with YouTube...")
    if not os.path.exists(args.secrets):
        print(
            f"\nError: {args.secrets} not found.\n"
            "To get it:\n"
            "  1. https://console.cloud.google.com/ → New project\n"
            "  2. Enable YouTube Data API v3\n"
            "  3. OAuth consent screen → add yourself as test user\n"
            "  4. Credentials → Create OAuth 2.0 Client (Desktop) → Download JSON\n"
            "  5. Rename the file to client_secrets.json\n"
        )
        sys.exit(1)
    from auth import get_youtube_service
    youtube = get_youtube_service(args.secrets)

    # 3. Upload
    status_msg = f"scheduled for {args.schedule}" if args.schedule else "publishing as public"
    print(f"\n[3/3] Uploading video ({status_msg})...")
    from uploader import upload_video
    video_id = upload_video(
        youtube,
        args.video,
        metadata,
        thumbnail_path=args.thumbnail,
        publish_at=args.schedule,
    )

    print(f"\nDone! https://www.youtube.com/watch?v={video_id}")


if __name__ == "__main__":
    main()

import os
import pickle
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

SCOPES = [
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube",
]
TOKEN_FILE = "token.pickle"


def get_youtube_service(client_secrets_file: str = "client_secrets.json"):
    """Authenticate and return a YouTube API service client.

    On first run opens a browser for OAuth consent. Subsequent runs reuse
    the cached token in token.pickle.

    To get client_secrets.json:
    1. Go to https://console.cloud.google.com/
    2. Create a project → Enable YouTube Data API v3
    3. OAuth consent screen → Add your Google account as test user
    4. Credentials → Create OAuth 2.0 Client ID (Desktop app)
    5. Download JSON → rename to client_secrets.json
    """
    credentials = None

    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "rb") as f:
            credentials = pickle.load(f)

    if not credentials or not credentials.valid:
        if credentials and credentials.expired and credentials.refresh_token:
            credentials.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(client_secrets_file, SCOPES)
            credentials = flow.run_local_server(port=0)
        with open(TOKEN_FILE, "wb") as f:
            pickle.dump(credentials, f)

    return build("youtube", "v3", credentials=credentials, cache_discovery=False)

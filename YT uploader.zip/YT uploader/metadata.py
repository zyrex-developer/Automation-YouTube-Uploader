import json
import anthropic

client = anthropic.Anthropic()

SYSTEM_PROMPT = """You are a YouTube SEO expert. Given a video script or transcript,
generate metadata that maximizes click-through rate and discoverability.

Rules:
- Title: keyword-first, 50-60 chars, creates curiosity or states clear value
- Description: first 2 lines are the hook (shown before "Show more"), then timestamps,
  then 3-5 keyword-rich paragraphs, then links section
- Tags: mix of 5 broad + 5-8 specific tags (total 10-13), no duplicates
- category_id: pick the most accurate YouTube category number:
  1=Film, 2=Autos, 10=Music, 15=Pets, 17=Sports, 19=Travel, 20=Gaming,
  22=People&Blogs, 23=Comedy, 24=Entertainment, 25=News, 26=HowTo,
  27=Education, 28=Science&Tech, 29=Nonprofits"""

OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "description": {"type": "string"},
        "tags": {"type": "array", "items": {"type": "string"}},
        "category_id": {"type": "string"},
        "default_language": {"type": "string"},
    },
    "required": ["title", "description", "tags", "category_id", "default_language"],
    "additionalProperties": False,
}


def generate_metadata(script: str, channel_niche: str = "") -> dict:
    """Use Claude to generate SEO-optimized YouTube metadata from a script."""
    niche_line = f"Channel niche: {channel_niche}\n\n" if channel_niche else ""
    user_prompt = f"{niche_line}Script/transcript:\n{script}"

    response = client.messages.create(
        model="claude-opus-4-7",
        max_tokens=2048,
        thinking={"type": "adaptive"},
        output_config={"format": {"type": "json_schema", "schema": OUTPUT_SCHEMA}},
        system=[
            {
                "type": "text",
                "text": SYSTEM_PROMPT,
                "cache_control": {"type": "ephemeral"},
            }
        ],
        messages=[{"role": "user", "content": user_prompt}],
    )

    text_block = next(b for b in response.content if b.type == "text")
    return json.loads(text_block.text)
